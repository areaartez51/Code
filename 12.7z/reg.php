<?php
$login = $_GET['login'];
$password=$_GET['password'];
$password2=$_GET['password2'];
if ($password==$password2){
	$file= fopen("users/$login.txt", "w+");
	$password=md5($password);
fwrite($file,$password);
fclose($file);

exit("Регистрация прошла успешно");
}
else{
exit("Ошибка регистрации");
}

?>